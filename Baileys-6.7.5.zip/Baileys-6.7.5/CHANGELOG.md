## 6.7.5 (2024-06-12)


### Bug Fixes

* **master:** fix lockfile (after [#847](https://github.com/WhiskeySockets/Baileys/issues/847)) ([c964615](https://github.com/WhiskeySockets/Baileys/commit/c964615cf9b2eaaa6f72e2bd5fa660eb2ae9ab9b))



